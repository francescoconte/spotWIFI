$( document ).ready(function(){
	$( "#send1" ).click(function() {
        var phone1 = $( "#phone1" ).val();
        var message = $( "#mes1" ).val();
        var name1 = $( "#name1" ).val();
		$.post('mail.php', {'message' : message, 'name' : name1, 'phone' : phone1}, function( data ){
			if (data == 1) {
   $('#form-sl1').fadeOut(0); 
   $('#form-sl2').fadeIn(800); 
   $('form').find('#phone1, #mes1, textarea').val('');
			} else {
				alert('РїСЂРѕР±Р»РµРјС‹ СЃ РѕС‚РїСЂР°РІРєРѕР№ СЃРѕРѕР±С‰РµРЅРёСЏ, РїРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰Рµ СЂР°Р·')
			}
		});
    });
	
	
    $( "#send2" ).click(function() {
        var phone2 = $( "#phone2" ).val();
        var message = $( "#mes1" ).val();
        var name2 = $( "#name2" ).val();
		$.post('mail.php', {'message' : message, 'name' : name2, 'phone' : phone2}, function( data ){
			if (data == 1) {
   $('form').find('#phone2, #mes2').val('');
			} else {
				alert('РїСЂРѕР±Р»РµРјС‹ СЃ РѕС‚РїСЂР°РІРєРѕР№ СЃРѕРѕР±С‰РµРЅРёСЏ, РїРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰Рµ СЂР°Р·')
			}
		});
    });
  
  
     $( "#send3" ).click(function() {
        var phone2 = $( "#phone3" ).val();
        var message = $( "#message" ).val();
        var name2 = $( "#name3" ).val();
		$.post('mail.php', {'message' : message, 'name' : name2, 'phone' : phone2}, function( data ){
			if (data == 1) {
   $('form#popup1').fadeOut();
   $('form#popup3').fadeOut();      
   $('div#popup2').delay(500).fadeIn(300);
   $('form').find('input, textarea').val('');
			} else {
				alert('РїСЂРѕР±Р»РµРјС‹ СЃ РѕС‚РїСЂР°РІРєРѕР№ СЃРѕРѕР±С‰РµРЅРёСЏ, РїРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰Рµ СЂР°Р·')
			}
		});
    }); 
  
  
});