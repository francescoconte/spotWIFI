		$(document).ready(function() {
            var clickneSlider = 0; clickMenu = 0; 
            var cloudSliderCount = 1;
            var widthSlide = $('.planirovki--slider--block').width();
            slideCol = $('.slid-pl').length;
            widthSliderBlock = widthSlide * slideCol;
            leftSlDinamic = 0;
            sliderClick = 0;
            montSou = ['September',' October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June'];
            
  
            
            
  // slider          
            
                $(function(slider){ 
        $('#slide--wrap').css('width' , widthSliderBlock); 
        $('.slid-pl').css('width' , widthSlide); 
         }); 
            
        $('#right-p-s').click(function(right) {
        if (sliderClick + 1 < slideCol) {
        leftSlDinamic = leftSlDinamic - widthSlide;
        $('#slide--wrap').css('left' , leftSlDinamic);
        sliderClick = sliderClick + 1;
        $('#big').html(sliderClick + 1); 
        
            
        // paginator    
        if (sliderClick == 0) {
        $('#dot-1').addClass('active');
        $('#dot-2').removeClass('active');
        }  else {
            
        if (sliderClick == 1) {
        $('#dot-2').addClass('active');
        $('#dot-1').removeClass('active');
        } else {
            
        if (sliderClick == 2) {
        $('#dot-3').addClass('active');
        $('#dot-2').removeClass('active');
        } else {
            
        if (sliderClick == 3) {
        $('#dot-4').addClass('active');
        $('#dot-3').removeClass('active');
        }  else {
            
        if (sliderClick == 4) {
        $('#dot-5').addClass('active');
        $('#dot-4').removeClass('active');
        }    }}}}
        
        } 
            
                    else { if (sliderClick == 4) {
        leftSlDinamic = 0;
        $('#dot-5').removeClass('active');    
        $('#slide--wrap').css('left' , leftSlDinamic);
        sliderClick = 0;
        $('#title-months').html(montSou[sliderClick]);
        $('#big').html(sliderClick + 1); 
                // paginator    
        if (sliderClick == 0) {
        $('#dot-1').addClass('active');
        $('#dot-2').removeClass('active');
        }  else {
            
        if (sliderClick == 1) {
        $('#dot-2').addClass('active');
        $('#dot-3').removeClass('active');
        } else {
            
        if (sliderClick == 2) {
        $('#dot-3').addClass('active');
        $('#dot-4').removeClass('active');
        } else {
            
        if (sliderClick == 3) {
        $('#dot-4').addClass('active');
        $('#dot-5').removeClass('active');
        }  else {
            
        if (sliderClick == 4) {
        $('#dot-5').addClass('active');
        $('#dot-4').removeClass('active');
        }    }}}}    
            
            
            
        }
            
            
        }    
            
  });    
            
            
        $('#left-p-s').click(function(left) {
         
        if (sliderClick >= 1) {
        leftSlDinamic = leftSlDinamic + widthSlide;
        $('#slide--wrap').css('left' , leftSlDinamic);
        sliderClick = sliderClick - 1;
        $('#title-months').html(montSou[sliderClick]);
        $('#big').html(sliderClick + 1); 
                // paginator    
        if (sliderClick == 0) {
        $('#dot-1').addClass('active');
        $('#dot-2').removeClass('active');
        }  else {
            
        if (sliderClick == 1) {
        $('#dot-2').addClass('active');
        $('#dot-3').removeClass('active');
        } else {
            
        if (sliderClick == 2) {
        $('#dot-3').addClass('active');
        $('#dot-4').removeClass('active');
        } else {
            
        if (sliderClick == 3) {
        $('#dot-4').addClass('active');
        $('#dot-5').removeClass('active');
        }  else {
            
        if (sliderClick == 4) {
        $('#dot-5').addClass('active');
        $('#dot-4').removeClass('active');
        }    }}}} 
        } 
            else { if (sliderClick == 0) {
        leftSlDinamic = (slideCol - 1) * -widthSlide;
        $('#dot-1').removeClass('active');    
        $('#slide--wrap').css('left' , leftSlDinamic);
        sliderClick = 4;
        $('#title-months').html(montSou[sliderClick]);
        $('#big').html(sliderClick + 1); 
                // paginator    
        if (sliderClick == 0) {
        $('#dot-1').addClass('active');
        $('#dot-2').removeClass('active');
        }  else {
            
        if (sliderClick == 1) {
        $('#dot-2').addClass('active');
        $('#dot-3').removeClass('active');
        } else {
            
        if (sliderClick == 2) {
        $('#dot-3').addClass('active');
        $('#dot-4').removeClass('active');
        } else {
            
        if (sliderClick == 3) {
        $('#dot-4').addClass('active');
        $('#dot-5').removeClass('active');
        }  else {
            
        if (sliderClick == 4) {
        $('#dot-5').addClass('active');
        $('#dot-4').removeClass('active');
        }    }}}}    
            
            
            
        }
            
            
        }
                 
          });             
          
            
            
 $('#dot-1').click(function() {     
     
        leftSlDinamic = 0;
        $('#slide--wrap').css('left' , leftSlDinamic);
        sliderClick = 0;
        $('#big').html(sliderClick + 1);    
        $('#dot-1').addClass('active');
        $('#dot-2').removeClass('active');
        $('#dot-3').removeClass('active');
        $('#dot-4').removeClass('active');
        $('#dot-5').removeClass('active');

       });      
            
                      
            
 $('#dot-2').click(function() {     
     
        leftSlDinamic = leftSlDinamic - widthSlide;
        $('#slide--wrap').css('left' , leftSlDinamic);
        sliderClick = 1;
        $('#big').html(sliderClick + 1);    
        $('#dot-2').addClass('active');
        $('#dot-1').removeClass('active');
        $('#dot-3').removeClass('active');
        $('#dot-4').removeClass('active');
        $('#dot-5').removeClass('active');

       });      
            
                    
 $('#dot-3').click(function() {     
     
        leftSlDinamic = 0 - (2 * widthSlide);
        $('#slide--wrap').css('left' , leftSlDinamic);
        sliderClick = 2;
        $('#big').html(sliderClick + 1);    
        $('#dot-3').addClass('active');
        $('#dot-2').removeClass('active');
        $('#dot-1').removeClass('active');
        $('#dot-4').removeClass('active');
        $('#dot-5').removeClass('active');

       });      
            
                   
                    
 $('#dot-4').click(function() {     
     
        leftSlDinamic = 0 - (3 * widthSlide);
        $('#slide--wrap').css('left' , leftSlDinamic);
        sliderClick = 3;
        $('#big').html(sliderClick + 1);    
        $('#dot-4').addClass('active');
        $('#dot-2').removeClass('active');
        $('#dot-1').removeClass('active');
        $('#dot-3').removeClass('active');
        $('#dot-5').removeClass('active');

       });      
                            
 $('#dot-5').click(function() {     
     
        leftSlDinamic = 0 - (4 * widthSlide);
        $('#slide--wrap').css('left' , leftSlDinamic);
        sliderClick = 4;
        $('#big').html(sliderClick + 1);    
        $('#dot-5').addClass('active');
        $('#dot-2').removeClass('active');
        $('#dot-1').removeClass('active');
        $('#dot-3').removeClass('active');
        $('#dot-4').removeClass('active');

       });      
            
            
             
            
            
            
        $("#button-1, #button-2, #button-3, #button-5").click(function() {

             $(".fix-popup").fadeIn(800);     
            
        });   
            
        $("#button-4").click(function() { 
        $("#form-sl1").fadeOut(0);       
        $("#form-sl2").fadeIn(800);       
            
        }); 
                        
        $(".close").click(function() {
        $("#form-sl2").fadeOut(0);       
        $("#form-sl1").fadeIn(800); 
        $(".fix-popup").fadeOut(800);      
            
        });              
            
            
            
            
        $(".stick").click(function() {
            
            if (clickneSlider == 0) {
             $("#slide1").fadeOut(1000);    
             $("#slide2").fadeIn(1000);    
              clickneSlider = 1;  
                
            } else {
            
            $("#slide2").fadeOut(1000);    
            $("#slide1").fadeIn(1000);    
            clickneSlider = 0; 
            
            
        }
            
            
            
        });  
            
            
            
      $(".regular").slick({
        dots: true,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1
      });            
      $(".regular2").slick({
        dots: true,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1
      });

            

	$("nav").on("click","a", function (event) {
		//отменяем стандартную обработку нажатия по ссылке
		event.preventDefault();

		//забираем идентификатор бока с атрибута href
		var id  = $(this).attr('href'),

		//узнаем высоту от начала страницы до блока на который ссылается якорь
			top = $(id).offset().top;
		
		//анимируем переход на расстояние - top за 1500 мс
		$('body,html').animate({scrollTop: top}, 800);
	});
  
            
 
  
            
            
             });       





  $(window).scroll(function() {


      $('header').addClass('black');     
      
     if (($(this).scrollTop() >= 500)) {
         
    
      
     } else {
         
     $('header').removeClass('black');    
         
     }
      
               }); 
      
