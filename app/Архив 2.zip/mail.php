<?php
header('Content-Type: text/html; charset=utf-8');

$headers =  'MIME-Version: 1.0' . "\r\n"; 
$headers .= 'From: my site <info@address.com>' . "\r\n";
$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n"; 
$result = mail('francescolucania@be-simple.su', 'Запрос с сайта', "name: ".$_POST['name']." <br>". "phone: " . $_POST['phone'] . "<br>" . $_POST['message'], $headers);
if (!$result) {
       echo '2';
}


echo '1';